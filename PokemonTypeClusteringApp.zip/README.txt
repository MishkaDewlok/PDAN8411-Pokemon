This ZIP contains a Jupyter notebook that builds a fun Gradio app to predict Pokémon types using K-Means clustering.
Dataset required: Download from https://www.kaggle.com/datasets/abcsds/pokemon and place 'Pokemon.csv' in the same folder as the notebook.
